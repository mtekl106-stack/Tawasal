import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// v6.0 - تواصل النسخة الكاملة
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(TawasalApp());
}

// الالوان الرسمية لتواصل
const Color primaryBlue = Color(0xFF0A1F44); // ازرق ملكي
const Color primaryGold = Color(0xFFFFD700); // ذهبي

class TawasalApp extends StatefulWidget {
  @override
  _TawasalAppState createState() => _TawasalAppState();
}

class _TawasalAppState extends State<TawasalApp> {
  bool isArabic = true;
  void toggleLanguage() => setState(() => isArabic = !isArabic);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تواصل v6.0',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: primaryBlue,
        scaffoldBackgroundColor: primaryBlue,
        appBarTheme: AppBarTheme(backgroundColor: primaryBlue, elevation: 0),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(primary: primaryGold, onPrimary: primaryBlue),
        ),
      ),
      home: SplashScreen(isArabic: isArabic, toggleLanguage: toggleLanguage),
    );
  }
}

// 1. شاشة البداية v6.0
class SplashScreen extends StatefulWidget {
  final bool isArabic;
  final Function toggleLanguage;
  SplashScreen({required this.isArabic, required this.toggleLanguage});
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => StreamBuilder<User?>(
            stream: FirebaseAuth.instance.authStateChanges(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Scaffold(
                  backgroundColor: primaryBlue,
                  body: Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(primaryGold))),
                );
              }
              if (snapshot.hasData) return MainScreen(isArabic: widget.isArabic, toggleLanguage: widget.toggleLanguage);
              return AuthScreen(isArabic: widget.isArabic, toggleLanguage: widget.toggleLanguage);
            },
          ),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBlue,
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          // اللووقو الرسمي v6.0
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: primaryGold,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: primaryGold.withOpacity(0.5), blurRadius: 20)],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Text('ت', style: TextStyle(fontSize: 70, color: primaryBlue, fontWeight: FontWeight.bold)),
                Positioned(top: 25, child: Icon(Icons.circle, size: 8, color: primaryBlue)),
                Positioned(top: 40, left: 40, child: Icon(Icons.circle, size: 8, color: primaryBlue)),
                Positioned(top: 40, right: 40, child: Icon(Icons.circle, size: 8, color: primaryBlue)),
              ],
            ),
          ),
          SizedBox(height: 20),
          Text('تواصل', style: TextStyle(color: primaryGold, fontSize: 32, fontWeight: FontWeight.bold)),
          Text('حيث يبدأ السودان الجديد', style: TextStyle(color: Colors.white70, fontSize: 14)),
          SizedBox(height: 10),
          Text('v6.0', style: TextStyle(color: Colors.white38, fontSize: 12)),
        ]),
      ),
    );
  }
}

// 2. التسجيل والدخول v6.0
class AuthScreen extends StatefulWidget {
  final bool isArabic;
  final Function toggleLanguage;
  AuthScreen({required this.isArabic, required this.toggleLanguage});
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool isLogin = true;
  bool loading = false;

  Map<String, String> get t => widget.isArabic
      ? {
          'title': 'تواصل',
          'subtitle': 'حيث يبدأ السودان الجديد',
          'email': 'الايميل',
          'password': 'كلمة السر',
          'login': 'دخول',
          'register': 'تسجيل جديد',
          'noAccount': 'ماعندك حساب؟ سجل',
          'haveAccount': 'عندك حساب؟ ادخل',
        }
      : {
          'title': 'Tawasal',
          'subtitle': 'Where Sudan Begins Anew',
          'email': 'Email',
          'password': 'Password',
          'login': 'Login',
          'register': 'Register',
          'noAccount': 'No account? Register',
          'haveAccount': 'Have account? Login',
        };

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _auth() async {
    final email = _email.text.trim();
    final pass = _password.text.trim();
    if (email.isEmpty || pass.isEmpty) {
      _showSnack(widget.isArabic ? 'املأ الحقول' : 'Please fill the fields');
      return;
    }

    setState(() => loading = true);
    try {
      if (isLogin) {
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: pass);
        // on success, StreamBuilder from SplashScreen will navigate to MainScreen
      } else {
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email, password: pass);
        final uid = cred.user?.uid;
        if (uid != null) {
          // create a user document
          await FirebaseFirestore.instance.collection('users').doc(uid).set({
            'email': email,
            'createdAt': FieldValue.serverTimestamp(),
            'displayName': '',
          });
        }
      }
    } on FirebaseAuthException catch (e) {
      _showSnack(e.message ?? (widget.isArabic ? 'خطأ في المصادقة' : 'Authentication error'));
    } catch (e) {
      _showSnack(widget.isArabic ? 'خطأ غير متوقع' : 'Unexpected error');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBlue,
      appBar: AppBar(
        title: Text(t['title']!),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.language, color: primaryGold),
            onPressed: () => widget.toggleLanguage(),
            tooltip: widget.isArabic ? 'English' : 'العربية',
          ),
        ],
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 24),
          child: Card(
            color: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(t['subtitle']!, style: TextStyle(color: primaryBlue, fontSize: 16)),
                  SizedBox(height: 12),
                  TextField(
                    controller: _email,
                    decoration: InputDecoration(labelText: t['email']),
                    keyboardType: TextInputType.emailAddress,
                  ),
                  SizedBox(height: 8),
                  TextField(
                    controller: _password,
                    decoration: InputDecoration(labelText: t['password']),
                    obscureText: true,
                  ),
                  SizedBox(height: 16),
                  loading
                      ? CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(primaryBlue))
                      : SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _auth,
                            child: Text(isLogin ? t['login']! : t['register']!),
                          ),
                        ),
                  TextButton(
                    onPressed: () => setState(() => isLogin = !isLogin),
                    child: Text(isLogin ? t['noAccount']! : t['haveAccount']!),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// 3. MainScreen (simple)
class MainScreen extends StatelessWidget {
  final bool isArabic;
  final Function toggleLanguage;
  MainScreen({required this.isArabic, required this.toggleLanguage});

  Map<String, String> get t => isArabic
      ? {'welcome': 'مرحبا', 'signout': 'خروج', 'addMessage': 'اضف رسالة'}
      : {'welcome': 'Welcome', 'signout': 'Sign out', 'addMessage': 'Add Message'};

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: Text('تواصل'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.language, color: primaryGold),
            onPressed: () => toggleLanguage(),
          ),
          IconButton(
            icon: Icon(Icons.exit_to_app, color: primaryGold),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
            },
            tooltip: t['signout'],
          ),
        ],
      ),
      body: Container(
        color: primaryBlue,
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(16),
              child: Card(
                child: ListTile(
                  leading: CircleAvatar(child: Text(user?.email?.substring(0, 1).toUpperCase() ?? '?')),
                  title: Text('${t['welcome']} ${user?.email ?? ''}'),
                  subtitle: Text(user?.uid ?? ''),
                ),
              ),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('messages').orderBy('createdAt', descending: true).snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) return Center(child: Text('Error loading messages', style: TextStyle(color: Colors.white)));
                  if (!snapshot.hasData) return Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(primaryGold)));
                  final docs = snapshot.data!.docs;
                  return ListView.builder(
                    reverse: true,
                    itemCount: docs.length,
                    itemBuilder: (context, index) {
                      final data = docs[index].data() as Map<String, dynamic>;
                      final text = data['text'] ?? '';
                      final email = data['email'] ?? '';
                      return ListTile(
                        title: Text
